// (function() {
//   'use strict';

  // submit送信trigger
  // var start = document.getElementById('start');
  // start.addEventListener('submit',

  // 検査完了ボタンクリック時



// })();
