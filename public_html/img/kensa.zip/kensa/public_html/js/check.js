(function() {
  'use strict';

  var compFlag = document.getElementById('compFlag');
  if(compFlag.value == 1){
    document.getElementById('comp_btn').className = 'btn comp completed';
  }
})();
