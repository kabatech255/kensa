<?php

namespace MyApp\Exception;

class UnmatchStoreId extends \Exception {

  protected $message = '登録されていない店番が入力されています';



}

 ?>
