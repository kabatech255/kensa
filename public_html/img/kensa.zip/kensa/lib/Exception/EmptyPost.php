<?php

namespace MyApp\Exception;

class EmptyPost extends \Exception {

  protected $message = 'フォームに空欄があります';



}

 ?>
