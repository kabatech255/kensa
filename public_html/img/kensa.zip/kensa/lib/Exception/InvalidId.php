<?php

namespace MyApp\Exception;

class InvalidId extends \Exception {

  protected $message = 'IDが半角数字7ケタで入力されていません';



}

 ?>
