<?php

namespace MyApp\Exception;

class UnmatchId extends \Exception {

  protected $message = '登録されていないIDが入力されています';



}

 ?>
