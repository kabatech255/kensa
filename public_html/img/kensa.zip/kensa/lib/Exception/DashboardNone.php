<?php

namespace MyApp\Exception;

class DashboardNone extends \Exception {

  protected $message = 'DashboardNone';



}

 ?>
