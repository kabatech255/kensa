<?php

namespace MyApp\Exception;

class InvalidStoreId extends \Exception {

  protected $message = '半角数字以外のものが入力されています';



}

 ?>
